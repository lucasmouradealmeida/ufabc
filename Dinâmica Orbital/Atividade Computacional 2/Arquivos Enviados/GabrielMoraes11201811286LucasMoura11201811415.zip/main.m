﻿%Sistema Dinâmico Sol-Júpiter-Partícula
%Sistema Normalizado & Adimensional
%Unidades se apresentam no SI

%Atividade Computacional 2
%Gabriel Moraes de Souza - RA:11201811286
%Lucas Moura de Almeida - RA:11201811415

clear all;
clc;

%Massa do Sol
m1 = 1.989*10^30;
%Massa de Júpiter
m2 = 1.898*10^27;
%Distância entre a Sol e Júpiter
r12 = 748.41*10^9;

%Massa reduzida
mi = (m2)/(m1+m2);

%Localização dos Pontos Lagrangianos
points;

%Curvas de Velocidade Zero
graph;




