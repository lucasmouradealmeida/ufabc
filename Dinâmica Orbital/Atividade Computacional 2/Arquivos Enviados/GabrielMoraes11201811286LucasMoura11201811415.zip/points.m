﻿%Localização dos Pontos Lagrangianos

%Pontos L4 e L5
L4 = [-mi+0.5 sqrt(3)/2];
L5 = [L4(1,1) -L4(1,2)];

%Pontos L1, L2 & L3
rt = zeros(5,1);
x = -100;
k = 1;
c = 6;

%Teorema de Bolzano

while k < c
    f0 =  x - (((1-mi)/((abs(x+mi))^3))*(x+mi)) - ((mi/((abs(x-1+mi))^3))*(x-1+mi));
    x = x + 0.005;
    f1 =  x - (((1-mi)/((abs(x+mi))^3))*(x+mi)) - ((mi/((abs(x-1+mi))^3))*(x-1+mi));
    
    if f0>0 && f1<0
        rt(k,1) = x - 0.005;
        k = k + 1;
    elseif f1>0 && f0<0
        rt(k,1) = x - 0.005;
        k = k + 1;
    end
end


Er = 10^-8;
z = 1;
Lx = ones(3,1);
j = 0;

%Método de Newton-Raphson
for i=1:2:5
    x0 = rt(i,1);
    Erx = 1;
    while Erx > Er
        
        fx =  x0 - (((1-mi)/((abs(x0+mi))^3))*(x0+mi)) - ((mi/((abs(x0-1+mi))^3))*(x0-1+mi));
        
        fx_d = ((3*mi*((mi+x0-1)^2))/((abs(mi+x0-1))^5))-((mi)/((abs(mi+x0-1))^3))-((1-mi)/((abs(mi+x0))^3))+((3*(1-mi)*((mi+x0)^2))/((abs(mi+x0))^5))+(1);      
        x = x0 - (fx/fx_d);
        Erx = (abs(x0-x))/(abs(x));
        x0 = x;
    end
    Lx(z,1) = x;
    z = z + 1;
end




