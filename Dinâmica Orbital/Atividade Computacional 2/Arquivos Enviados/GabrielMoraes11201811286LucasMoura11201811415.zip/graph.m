﻿%Curvas de Velocidade Zero

%Constante Gravitacional
G = 1;
%Sol
mi1 = G*(1-mi);
%Jupiter
mi2 = G*mi;

% Cj - Estimativas Iniciais
CL1 = (3) + (3^(3/4))*((mi2)^(2/3))-((10*(mi2))/3); 
CL2 = (3) + (3^(3/4))*(mi2^(2/3))-((14*mi2)/3); 
CL3 = 3 + mi2;
CL4 = 3 - mi2;
CL5 = CL4;

%Cj - Valores Corrigidos para o sistema em análise

CLj = [CL1+0.1 CL2+0.01821 CL3 CL4+0.001 CL5];


%Plot dos gráficos

j = 0.01;
k = 2;

x = -k:j:k;
y = -k:j:k;
[X,Y] = meshgrid(x,y);
        
for i=1:5
    Cj = CLj(1,i);
    
    Z = X.^2 + Y.^2 + 2.*(((1-mi)./(sqrt((X+mi).^2+Y.^2))) + ((mi)./(sqrt((X-1+mi).^2+Y.^2)))) - Cj;
    
    L = [L4; L5; Lx(1,1) 0; Lx(2,1) 0; Lx(3,1) 0];
    
    figure(i)
    clf;
    contour(X,Y,Z,[0 0],'k')
    hold on
    scatter(L(:,1),L(:,2),'filled')
    grid on
    title(sprintf('C_J = %.4f',CLj(1,i)));
end
