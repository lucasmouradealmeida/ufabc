﻿# Codigo de interacoes entre anomalias com formulacao numerica de Newton Raphson
#---------------------------------------------------

#limpar prints da tela
clc;

# entrada de dados
Qdois_Entrada_de_input;

Qdois_Metodo_Numerico;

#------------------------------------------------------